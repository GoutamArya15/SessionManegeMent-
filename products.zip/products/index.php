<?php
session_start();
$session_mesage = 1;
if (isset($_SESSION['success'])) {
?>
    <div class="alert alert-success alert-dismissible fade show w-50 mt-2 " role="alert">
        <?php echo $_SESSION['success'] ?>
        <button type="button" class="btn-close pb-1" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
<?php
    $session_mesage  = 2;
}

if ($session_mesage = 2) {
    unset($_SESSION['success']);
}



?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <script src="https://code.jquery.com/jquery-3.7.1.min.js" integrity="sha256-/JqT3SQfawRcv/BIHPThkBvs0OEvtFFmqPF/lYI/Cxo=" crossorigin="anonymous"></script>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        .products {
            display: flex;
            gap: 20px;
            margin-left: 25px;
        }

        .product {
            height: auto;
            width: 7%;
            border: 2px solid black;
            padding-left: 10px;
            padding-bottom: 10px;
            padding-right: 10px;
        }

        button {
            margin-top: 10px;
        }

        h4 {
            margin-top: 20px;
            margin-left: 20px;
            color: #1f761f;
            background-color: #b3dff1;
            width: 20%;
        }
        a{
            text-decoration: none;
            color: #1f761f;
            margin-left: 20px;
        }
    </style>
</head>

<body>

    <h3>SHOPING</h3>
    <div class="products">
        <!-- Product1 -->
        <div class="product">
            <h3>Bag</h3>
            <p>Price:$500</p>
            <form action="product-data.php" method="POST">
                <input type="text" hidden value="1" name="product_id">
                <input type="number" max="10" min="1" value="1" name="product_quantity"><br>
                <input type="text" hidden value="Bag" name="product_name">
                <input type="text" hidden value="500" name="product_price">
                <button type="submit" name="submit" onclick="btn()">Add To Cart</button>
            </form>
        </div>
        <!-- Product2 -->
        <div class="product">
            <h3>PEN</h3>
            <p>Price:$6</p>
            <form action="product-data.php" method="POST">
                <input type="text" hidden value="2" name="product_id">
                <input type="number" max="10" min="1" value="1" name="product_quantity"><br>
                <input type="text" hidden value="Pen" name="product_name">
                <input type="text" hidden value="6" name="product_price">
                <button type="submit" name="submit" onclick="btn()">Add To Cart</button>
            </form>
        </div>
    </div>


    <h4><a href="cart.php">Your Products </a></h4>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.8/dist/umd/popper.min.js" integrity="sha384-I7E8VVD/ismYTF4hNIPjVp/Zjvgyol6VFvRkX/vR+Vc4jQkC+hVqc2pM8ODewa9r" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.min.js" integrity="sha384-0pUGZvbkm6XF6gxjEnlmuGrJXVbNuzT9qBBavbLwCsOGabYfZo0T0to5eqruptLy" crossorigin="anonymous"></script>
</body>

</html>