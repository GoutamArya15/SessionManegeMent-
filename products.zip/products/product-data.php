<?php
session_start();
// print_r($_SESSION);
if (isset($_POST['submit'])) {
    $check_id = 1;
    if (isset($_SESSION['products'])) {
        $products = $_SESSION['products'];
        foreach ($_SESSION['products'] as $key => $value) {
            if ($value['product_id'] == $_POST['product_id']) {
                $products[$key]['product_quantity'] += $_POST['product_quantity'];
                $_SESSION['products'] = $products;
                $check_id = 0;
                $_SESSION['success'] = "Successfull Add Item !";
                break;
            }
        }
    }
    if ($check_id != 0) {
        $items = [
            'product_id' => $_POST['product_id'],
            'product_name' => $_POST['product_name'],
            'product_price' => $_POST['product_price'],
            'product_quantity' => $_POST['product_quantity'],
        ];
        $products[] = $items;
        $_SESSION['products'] = $products;
        $_SESSION['success'] = "Successfull Add Item !";
    }
    header('Location: index.php ');
}
