<?php
session_start();
?>

<table border="2px solid black">
    <tr>
        <th>Product id</th>
        <th>Product Name</th>
        <th>Product Quantity</th>
        <th>Product Price</th>
        <th>Product Total Price</th>
    </tr>
    <?php
    if (isset($_SESSION['products'])) {
        $total = 0;
        foreach ($_SESSION['products'] as $key => $value) {
    ?>
            <tr>
                <td><?php echo $value['product_id'] ?></td>
                <td><?php echo $value['product_name'] ?></td>
                <td><?php echo $value['product_quantity'] ?></td>
                <td>$<?php echo $value['product_price'] ?></td>
                <td>$<?php echo $value['product_price'] * $value['product_quantity'] ?></td>
            </tr>
        <?php
            $total += $value['product_price'] * $value['product_quantity'];
        }
        ?>
        <tr>
            <td colspan="5">Total Price = $<?php echo $total ?> <i><a href="stripe.php?price=<?php echo $total ?>" style="text-decoration: none;margin-left: 20px;font-weight: bolder;color: brown;">Shop Now</a></i></td>
        </tr>
    <?php } else { ?>
        <tr>
            <td colspan="5"><i>Products Not Found</i></td>
        </tr>
    <?php } ?>
</table>