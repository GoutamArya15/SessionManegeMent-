<?php
// dd($request->price);
require_once('vendor/autoload.php');
\Stripe\Stripe::setApiKey("sk_test_51QVvYIGMFA43a0oW1RXr26nSFZOqlDRACbLhzo2W5RlTarukHQg1hFFRvBLjR4s2wCspZdaEDSVG6zB89wfoZNzg00Fxa61Ivy");

\Stripe\Charge::create([
    "amount" => 100 * $_POST['price'],
    "currency" => "usd",
    "source" => $_POST['stripeToken'],
    "description" => "Test payment from stripe"
]);

try {
    session_start();
    print_r($_SESSION);
    unset($_SESSION['products']);
    $_SESSION['success'] = "Your Payment Is Successfull!";
    header('Location:index.php');
} catch (\Exception $e) {
    echo "some thing went wrong";
}
